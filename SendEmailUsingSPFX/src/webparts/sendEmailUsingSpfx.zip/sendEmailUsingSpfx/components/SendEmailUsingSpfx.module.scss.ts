/* tslint:disable */
require("./SendEmailUsingSpfx.module.css");
const styles = {
  sendEmailUsingSpfx: 'sendEmailUsingSpfx_c2b8ac2e',
  container: 'container_c2b8ac2e',
  row: 'row_c2b8ac2e',
  title: 'title_c2b8ac2e',
  subject: 'subject_c2b8ac2e',
  message: 'message_c2b8ac2e',
  inputFileWraper: 'inputFileWraper_c2b8ac2e',
  inputFile: 'inputFile_c2b8ac2e',
  uploadedFile: 'uploadedFile_c2b8ac2e',
  uploadedFile1: 'uploadedFile1_c2b8ac2e',
  uploadedFile2: 'uploadedFile2_c2b8ac2e',
  column: 'column_c2b8ac2e',
  'ms-Grid': 'ms-Grid_c2b8ac2e',
  subTitle: 'subTitle_c2b8ac2e',
  description: 'description_c2b8ac2e',
  button: 'button_c2b8ac2e',
  label: 'label_c2b8ac2e'
};

export default styles;
/* tslint:enable */