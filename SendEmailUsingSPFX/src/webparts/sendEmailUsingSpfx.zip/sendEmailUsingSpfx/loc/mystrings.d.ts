declare interface ISendEmailUsingSpfxWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SendEmailUsingSpfxWebPartStrings' {
  const strings: ISendEmailUsingSpfxWebPartStrings;
  export = strings;
}
